<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig)
{
    
    $ADMIN->add('localplugins', new admin_category('localskillcat',
        get_string('pluginname', 'local_skillcat')));
    
    
	$settings = new admin_settingpage('local_skillcat', get_string('pluginname', 'local_skillcat'));
    $ADMIN->add('localskillcat', $settings);
	
	$settings->add(new admin_setting_configcheckbox(
        'local_skillcat/reportsenabled',
        get_string('reportsenabled', 'local_skillcat'),
        '',
        1
        ));
    
    $settings = null;
}