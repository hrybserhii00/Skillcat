<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version  = 2021030200;
$plugin->requires = 2018120302;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = 'Skillcat';

$plugin->component = 'local_skillcat'; // Full name of the plugin (used for diagnostics)

