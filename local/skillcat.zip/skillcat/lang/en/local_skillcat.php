<?php

$string['pluginname'] = 'Skillcat';
$string['reportsenabled'] = '';

